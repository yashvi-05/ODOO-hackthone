function handleLogin(event) {
  event.preventDefault();

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMsg = document.getElementById("error-msg");

  if (!username || !password) {
    errorMsg.textContent = "Please fill in both username and password.";
    return;
  }

  // No backend check for now – direct move
  window.location.href = "loading.html";
}

